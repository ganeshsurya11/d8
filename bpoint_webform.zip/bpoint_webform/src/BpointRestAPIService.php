<?php

namespace Drupal\bpoint_webform;

/**
 * For bpoint reset api service
 */
class BpointRestAPIService {
    /**
     * Payment process function
     *
     * @param object $form_state
     * @return json object
     */
    public function processPayment($form_state) {
        $config     = \Drupal::config('bpoint_webform.settings');
        $txn_mode   = $config->get('bpoint_txn_mode');
        $myObj = new \stdClass();
        // remove $ prefix from amount if added.
        $amount = str_replace( '$', '', $form_state->getValue('amount'));
        $myObj->TxnReq = array(
          "TestMode" => $txn_mode,
          "Action" => "payment",
          "Amount" => $amount * 100,
          "CardDetails" => array(
              "CardHolderName" => $form_state->getValue('card_holder_name'),
              "CardNumber" =>  $form_state->getValue('card_number'),
              "Cvn" => $form_state->getValue('cvn'),
              "ExpiryDate" => $form_state->getValue('expiry_month').''.$form_state->getValue('expiry_year'),
            ),
          "SubType" => "single",
          "Crn1" => 'Crn1-'.uniqid(),
          "Type" => "internet",
        );
       $payment_json_obj = json_encode($myObj);
       $response =  $this->sendPaymentRequest($payment_json_obj);
       return $response;
    }

    /**
     * Bpoint payment rest api request
     *
     * @param object $payment_json_obj
     * @return object
     */
    private function sendPaymentRequest($payment_json_obj) {
        $config = \Drupal::config('bpoint_webform.settings');
        $bpoint_merchant_id   =   $config->get('bpoint_merchant_id');
        $bpoint_txn_username  =   $config->get('bpoint_txn_username');
        $bpoint_txn_password  =   $config->get('bpoint_txn_password');
        $bpoint_api_url       =   $config->get('bpoint_url');
        $auths  = base64_encode($bpoint_txn_username.'|'.$bpoint_merchant_id.':|'.$bpoint_txn_password);
        $options = [
            'connect_timeout' => 30,
            //'debug' => true,
            'headers' => array(
            'Content-Type' => 'application/json',
            'Authorization' => $auths,
            ),
            'body' => $payment_json_obj,
            'verify' => true,
        ];
        $client = \Drupal::httpClient();
        $request = $client->request('POST', $bpoint_api_url, $options);
        $response = json_decode($request->getBody());
        //\Drupal::logger('ganesh_paymnt')->notice('<pre>'.print_r($response, true).'</pre>');
        return $response;
    }
}

