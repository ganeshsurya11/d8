<?php

namespace Drupal\bpoint_webform\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

class BpointApiSettingsForm extends ConfigFormBase {

    /**
     * {@inheritDoc}
     */
    public function getFormId() {
        return 'bpont_webform.admin_settings';
    }

    /**
     * {@inheritDoc}
     */
    protected function getEditableConfigNames() {
        return ['bpoint_webform.settings'];
    }

    /**
     * {@inheritDoc}
     */
    public function buildForm(array $form, FormStateInterface $form_state) {
        $config = $this->config('bpoint_webform.settings');
        $bpoint_txn_mode      =   $config->get('bpoint_txn_mode');
        $bpoint_merchant_id   =   $config->get('bpoint_merchant_id');
        $bpoint_txn_username  =   $config->get('bpoint_txn_username');
        $bpoint_txn_password  =   $config->get('bpoint_txn_password');
        $bpoint_api_url       =   $config->get('bpoint_url');
        $form['fieldgroup']   = [
            '#type' => 'fieldset',
            '#title' => 'bpoint Payment Configuration Settings',
            '#collapsible' => TRUE,
            '#collapsed' => FALSE
        ];
        $form['fieldgroup']['bpoint_txn_mode'] = [
            '#type' => 'select',
            '#title' => 'Transction Mode',
            '#required' => TRUE,
            '#options' => ['true' => 'Test', 'false' => 'Live'],
            '#default_value' => $bpoint_txn_mode
            //'#description' => t('Password required for the API access')
        ];
        $form['fieldgroup']['bpoint_url'] = [
            '#type' => 'textfield',
            '#title' => 'BPOINT Transaction URL',
            '#required' => TRUE,
            '#default_value' => $bpoint_api_url,
            '#description' => t('BPOINT Payment URL')
        ];
        $form['fieldgroup']['bpoint_merchant_id']    = [
            '#type' => 'textfield',
            '#title' => 'Merchant Id',
            '#required' => TRUE,
            '#default_value' => $bpoint_merchant_id,
            '#description' => t('Your Merchant ID')
        ];
        $form['fieldgroup']['bpoint_txn_username'] = [
            '#type' => 'textfield',
            '#title' => 'Username',
            '#required' => TRUE,
            '#default_value' => $bpoint_txn_username,
            '#description' => t('Username required for API access')
        ];
        $form['fieldgroup']['bpoint_txn_password'] = [
            '#type' => 'textfield',
            '#title' => 'Password',
            '#required' => TRUE,
            '#default_value' => $bpoint_txn_password,
            '#description' => t('Password required for the API access')
        ];
        return parent::buildForm($form, $form_state);
    }

    /**
     * {@inheritDoc}
     */
    public function submitForm(array &$form, FormStateInterface $form_state) {
        $this->config('bpoint_webform.settings')
               ->set('bpoint_url', $form_state->getValue('bpoint_url'))
               ->set('bpoint_txn_mode', $form_state->getValue('bpoint_txn_mode'))
               ->set('bpoint_merchant_id', $form_state->getValue('bpoint_merchant_id'))
               ->set('bpoint_txn_username', $form_state->getValue('bpoint_txn_username'))
               ->set('bpoint_txn_password', $form_state->getValue('bpoint_txn_password'))
               ->save();
        parent::submitForm($form, $form_state);
    }

}