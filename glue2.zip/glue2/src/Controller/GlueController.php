<?php

/**
 * @file
 * Contains \Drupal\glue\Controller\GlueController.
 */

namespace Drupal\glue\Controller;
use Drupal\Core\Controller\ControllerBase;

class GlueController extends ControllerBase {

  public function content() {

    $c = $this->bpoint();

    return array(
      '#type' => 'markup',
      '#markup' => 'test',
    );
  }

  public function bpoint() {
    $endpoint = 'https://www.bpoint.com.au/webapi/v3/txns/';
    // Make the request.
    $json = '{
      "TxnReq": {
        "Action": "payment",
        "Amount": 14550,
        "CardDetails": {
          "CardHolderName": "",
          "CardNumber": "5123456789012346",
          "Cvn": "132",
          "ExpiryDate": "0221"
        },
        "SubType": "single",
        "Crn1": "test crn99",
        "Type": "internet"
      }
    }';
    $options = [
      'connect_timeout' => 30,
      'debug' => true,
      'headers' => array(
        'Content-Type' => 'application/json',
        'Authorization' => 'c2NzZGVtb3xERU1PTlNUUkFUSU8yMTMxOnxuTWBrVHExNDA=',
      ),
      'body' => $json,
      'verify'=>true,
    ];
    $client = \Drupal::httpClient();
    $request = $client->request('POST', $endpoint, $options);
    $response = json_decode($request->getBody());
    return $response; 
  }

}
