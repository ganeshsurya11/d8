<?php

namespace Drupal\glue\Plugin\Field\FieldFormatter;

use Drupal\Component\Utility\Html;
use Drupal\Core\Field\FieldItemInterface;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Field\FormatterBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Plugin implementation of the 'planogram_formatter' formatter.
 *
 * @FieldFormatter(
 *   id = "planogram_formatter",
 *   label = @Translation("Planogram formatter"),
 *   field_types = {
 *     "planogram_field_type"
 *   }
 * )
 */
class PlanogramFormatter extends FormatterBase {
  /**
   * {@inheritdoc}
   */
  public static function defaultSettings() {
    // parent::defaultSettings();
    $settings = [];
    $settings['planogram_size'] = 200;
    return $settings;
  }

  /**
   * {@inheritdoc}
   */
  public function settingsForm(array $form, FormStateInterface $form_state) {
    $form['planogram_size'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Planogram Size'),
      '#default_value' => $this->getSetting('planogram_size'),
    ];
    return $form + parent::settingsForm($form, $form_state);;
  }


  /**
   * {@inheritdoc}
   */
  public function settingsSummary() {
    $summary = [];
    // Implement settings summary.
    $summary[] = 'Testing size: '.$this->getSetting('planogram_size');
    return $summary;
  }

  /**
   * {@inheritdoc}
   */
  public function viewElements(FieldItemListInterface $items, $langcode) {
    $elements = [];
    $ht = $this->getSetting('planogram_size');
    foreach ($items as $delta => $item) {
      // $elements[$delta] = ['#markup' => $this->viewValue($item)];
      $elements[$delta] = [
        '#type' => 'html_tag',
        '#tag' => 'h3',
        '#value' => $this->t('@ht This is the value @val', ['@val' => 'ganesh', '@ht' => $ht])
      ];
    }

    return $elements;
  }

  /**
   * Generate the output appropriate for one field item.
   *
   * @param \Drupal\Core\Field\FieldItemInterface $item
   *   One field item.
   *
   * @return string
   *   The textual output generated.
   */
  protected function viewValue(FieldItemInterface $item) {
    // The text value has no text format assigned to it, so the user input
    // should equal the output, including newlines.
    return nl2br(Html::escape($item->value));
  }

}
