<?php

namespace Drupal\glue\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides a 'GsBlock' block.
 *
 * @Block(
 *  id = "gs_block",
 *  admin_label = @Translation("Gs block"),
 * )
 */
class GsBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {
    $build = [];
    $build['#theme'] = 'gs_block';
     $build['gs_block']['#markup'] = 'Implement GsBlock.';

    return $build;
  }

}
